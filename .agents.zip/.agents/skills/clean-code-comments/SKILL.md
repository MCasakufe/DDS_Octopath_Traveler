---
name: clean-code-comments
description: 'It is from Clean Code, and the chapters that refers to this skill: Ch. 4 — Good vs. bad comments, when to use them.'
---

complete body
