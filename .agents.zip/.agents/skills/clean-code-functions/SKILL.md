---
name: clean-code-functions
description: 'Clean Code Ch. 3 guidance for small, focused C# functions, argument design, command-query separation, and readable control flow in the Octopath Traveler-inspired project.'
---

# Clean Code Functions

Use this skill for function size, responsibility, abstraction level, helper extraction, arguments, command-query separation, predicates, duplication, and function-level error flow.

## Priority Rule

- This file integrates the authoritative Cap 3 lecture guide and supersedes conflicting prior function guidance.
- Apply the preferred design targets first. Retain the compatible rubric guardrails as outer limits.

## Size and Structure

1. **Keep functions small**
- Prefer functions of approximately 4–5 lines.
- Treat methods above 15 lines as refactoring candidates unless a justified construction-only exception applies.
- A non-construction method above 60 lines is not acceptable.
- A non-construction method above 100 lines is a hard fail condition.
- Methods used only to build objects, such as factory or ability-builder construction flows, may be longer when necessary. This exception does not justify duplicated mapping, parsing, or validation logic.

2. **Do one thing at one abstraction level**
- A function must have one responsibility.
- Do not mix high-level orchestration with low-level implementation details.
- A short function can still violate this rule if it performs multiple tasks.

3. **Extract helpers until the flow is clear**
- Extract named helper methods until further extraction would no longer clarify the code.
- Place helpers close to and below their callers when practical so the file reads from high-level flow to detail.

4. **Limit nesting**
- Keep functions at no more than two indentation levels.

## Commands, Queries, and State

1. **Separate commands from queries**
- A command changes state. A query returns information without changing state.
- Do not combine mutation with an unrelated query.
- A domain action may return a structured result object when the caller needs the valid outcome, such as damage, a miss, a blocked attack, a failed flee attempt, or a defeated target. Do not use the returned value as an error code.

2. **Avoid output arguments**
- Do not use output arguments or `out` parameters.
- Return a result object instead.

3. **Store only genuine object state in fields**
- Do not move local data into fields merely to reduce an argument list.
- Use a field only when the data is genuine object state.

## Argument Design

1. **Minimize parameters**
- Prefer 0–2 parameters.
- Avoid more than 3 parameters.

2. **Group related values**
- Replace long related argument lists with focused request or value objects.

3. **Replace boolean flags with explicit behavior**
- Do not use boolean parameters to switch between behaviors.
- Use separate methods, commands, strategies, effects, or selectors.

```csharp
RenderSummary();
RenderDetailedReport();
```

## Readable Control Flow

1. **Extract complex conditions**
- Move complex conditions into named predicates.

```csharp
if (traveler.CanUse(skill)) Execute(skill);
```

2. **Remove duplication**
- Extract repeated logic blocks into focused helpers without hiding the high-level flow.

3. **Keep error handling separate**
- Throw exceptions instead of returning error codes.
- Keep error handling separate from the main control flow.
- Use `clean-code-errors` for broader exception, `null`, and `try-catch` guidance.

## Project-Specific Guidance

- Keep `Game.cs` at a high orchestration level: load runtime data, select a team, create battle state, and start battle execution.
- Review whether `BattleLoopRunner` mixes round flow with turn-resolution details. Extract helpers or delegate to turn commands.
- Keep each turn command focused on one action: basic attack, skill use, defend, flee, or beast action.
- Review executors such as `TravelerSkillExecutor`, `TravelerBasicAttackExecutor`, `BeastAttackExecutor`, and `BeastAttackHitExecutor` for long methods, deep nesting, and mixed abstraction levels.
- Prefer existing request and result objects in the beast-attack pipeline over long argument lists.
- Introduce focused request objects when skill effects, selectors, calculators, parsers, or validators require several related values.
- Extract named predicates for eligibility, validation, target selection, break conditions, and battle completion.
- Review factories and parsers for duplicated mapping, parsing, or validation steps. Extract shared helpers without hiding the high-level flow.
- Avoid boolean parameters that switch between different battle behaviors. Prefer separate commands, strategies, effects, or selectors.

## Cross-Skill Link

- When extracting helpers reveals groups that use separate subsets of shared parameters or fields, continue with `clean-code-classes`: keep only genuine object state in fields and move each cohesive responsibility into a dedicated class.

## Review Checklist

- Functions are preferably approximately 4–5 lines and remain within compatible rubric guardrails.
- Each function has one task.
- Abstraction levels are not mixed.
- Helper methods clarify the flow and appear close to and below their callers when practical.
- No function has more than 3 parameters; 0–2 is preferred.
- Related values are grouped into request or value objects.
- Fields store genuine object state only.
- No output arguments or `out` parameters remain.
- No boolean flag parameters remain.
- Commands and queries are separate, except that a domain action may return a structured valid-outcome result object.
- Complex conditions have descriptive predicate names.
- Duplicate blocks are extracted.
- Nesting stays within two levels.
- Error handling is separate from the main task and uses exceptions rather than error codes.
- Long functions, excessive parameters, output arguments, boolean flags, duplicated code, deep nesting, inline complex conditions, and mixed abstraction levels are grading-risk items.