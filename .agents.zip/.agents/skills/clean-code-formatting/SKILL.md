---
name: clean-code-formatting
description: 'It is from Clean Code, and the chapters that refers to this skill: Ch. 5 — Vertical/horizontal layout, stepdown rule.'
---

complete body
