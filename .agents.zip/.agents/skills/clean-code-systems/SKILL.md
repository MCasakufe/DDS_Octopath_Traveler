---
name: clean-code-systems
description: 'Clean Code systems guidance for MVC ownership, Dependency Inversion, presentation-neutral models, structured battle outcomes, polymorphic View rendering, user-driven target selection, narrow view abstractions, composition-root construction, and separation of orchestration from domain logic in the Octopath Traveler-inspired project.'
---

# Clean Code Systems and MVC Boundaries

Use this skill for Model-View-Controller ownership, dependency direction, view abstraction, structured result rendering, user-driven selection flow, composition-root wiring, presentation neutrality, and separation of orchestration from domain logic.

## Priority Rule

- This file integrates the authoritative MVC, Cap 10, and SOLID lecture guides and supersedes conflicting prior architecture guidance.
- When placement is unclear, classify code by whether it is user-facing, requires a view to operate, or can operate without a view.
- Make high-level orchestration and low-level implementations depend on abstractions rather than on each other directly.

## Layer Ownership

1. **Place application flow in `Controller`**
- `Controller` decides what happens and when.
- Keep `Game.cs`, `BattleLoopRunner`, and turn commands focused on orchestration.
- Keep `BattleLoopRunner` focused on round flow. Do not add damage, formatting, parsing, or validation logic.
- Keep turn commands focused on coordinating one action.

2. **Place domain logic in `Models`**
- Put game state, rules, calculations, validation, domain parsing, and storage logic in `Models`.
- Keep battle rules inside `Models/Battle`, including state transitions, damage calculations, skill execution, passive effects, conditions, deterministic selectors, and winner evaluation.
- Keep calculations in dedicated Models classes such as damage calculators and resolvers.
- Keep runtime-data loading, reading, JSON parsing, definition parsing, and catalog construction inside `Models/RuntimeData`, using separate focused classes when they change for different reasons.
- Keep team-file parsing and team validation inside `Models/TeamSelection`, but separate those responsibilities using focused classes such as `TeamFileParser` and `TeamSetupValidator`.

3. **Place user interaction in `View`**
- Put user input, output, messages, and formatting in `View`.
- Keep prompts, option formatting, battle-state display, team-selection screens, action menus, and user-input parsing inside `View`.
- Keep team-selection prompts, option formatting, and user input inside `TeamSelectionView`.
- Keep console- and GUI-specific behavior inside `Octopath-Traveler-View`.

## Placement Rule

- Put user-facing interaction and formatting in `View`.
- Put code that requires a view to operate in `Controller`.
- Put code that can operate without a view in `Models`.
- Distinguish user-input parsing in `View` from runtime-data and team-domain parsing in `Models`.

## Dependency Direction

1. **Apply Dependency Inversion**
- Depend on abstractions, not concrete implementations.
- Make high-level classes and low-level classes depend on interfaces.
- Keep abstractions independent of implementation details.

2. **Keep `Models` presentation-neutral and independent**
- `Models` must not depend on `Controller` or `View`.
- Keep battle models, skills, passive skills, effects, selectors, factories, and executors independent of presentation details.
- Keep effects inside Models and focused on changing battle state.
- Do not make damage, healing, revive, or status-effect classes generate user-facing text.
- Do not store printable messages or display logs such as `List<string>` inside battle state merely so View can print them.

3. **Keep `View` independent of `Controller`**
- `View` must not depend on `Controller`, avoiding circular dependencies.

4. **Do not mutate Models directly from View**
- Allow views to receive model objects or result objects for display.
- Do not let views modify model data or invoke editing operations directly.

5. **Keep project ownership visible**
- Separate Controller, Models, and View classes clearly, using folders or separate projects.

## Target-Selection Flow

1. **Keep deterministic selection in Models**
- Keep deterministic target-selection rules inside Models.
- Keep target selectors independent of View.

2. **Coordinate user-driven selection through Controller and View**
- When target selection requires user input, let Controller coordinate View input and pass the selection into Models.
- Do not make Models depend on View merely because a target must be selected interactively.

## Structured Results and View Rendering

1. **Return structured outcomes from Models**
- Return structured action-result objects from Models instead of printable strings.
- Return structured outcomes such as damage, HP changes, status effects, revives, breaks, and turn results.
- Prefer specialized result types such as `TravelerSkillResult`, `TravelerTurnOutcome`, and beast-attack result objects over a generic state object that carries mutable fields and presentation logs.

2. **Format outcomes inside View**
- Let classes in `Octopath-Traveler-View/Battle` convert structured outcomes into messages.
- Let View classes such as `BattleActionView` and factories such as `TravelerTurnOutcomeFactory` format, group, and order result messages.

3. **Extend presentation polymorphically**
- Do not create one general View method per effect type, such as `AnnounceFireDamage()` or `AnnounceQueueDelay()`.
- Render results polymorphically in View.
- Add a result renderer for each genuinely new presentation type without changing the general View interface.

## View Abstraction

1. **Inject view abstractions into orchestration**
- Inject view abstractions into `Game.cs`, `BattleLoopRunner`, and turn commands.
- Do not couple them to `ConsoleView`, GUI classes, `ReadLine()`, or `WriteLine()`.

2. **Expose domain-specific view operations**
- Do not call low-level console or GUI operations from `Controller`.
- Expose game-level methods instead of low-level input, output, formatting, file, or directory methods.
- Consider narrow interfaces such as:

```csharp
interface ITeamSelectionView { TeamSelection SelectTeam(); }
interface IBattleView { TravelerTurnSelection AskTurn(); void Show(BattleState state); }
```

3. **Support interchangeable views**
- Let console and GUI implementations satisfy the same interfaces.
- Ensure that a new view can be added without modifying `Models` or battle orchestration.
- Preserve any required GUI startup callback behind the view abstraction.

4. **Split view abstractions when dependencies differ**
- Split view implementations further, or add a view factory, when team selection, battle display, and main-menu views need different dependencies.
- Use small role-specific interfaces so each client depends only on the operations it uses.
- Use `clean-code-classes` for the full Interface Segregation review.

## Composition Root

- Use `Program.cs` or `Script.cs` as the composition root: choose concrete views and adapters, create the controller, and start the application.
- Do not construct concrete console views, GUI views, or infrastructure adapters inside Models or orchestration classes.

```csharp
IView view = new ConsoleView();
view.Start(() => new Game(view).Play());
```

## Cross-Skill Links

- Use `clean-code-objects` when Controller or View navigates through Models internals, when `BattleState` becomes an unrestricted mutable parameter bag, or when a specialized request or result data structure is more appropriate.
- Use `clean-code-classes` for cohesive class responsibilities, interface segregation, active-skill composition, event-driven passive-skill handlers, and polymorphic modeling of extensible battle behavior.
- Use `clean-code-boundaries` for adapters around external or unmodifiable dependencies, runtime-data sources, file-system operations, and directory operations.

## Review Checklist

- Controller, Models, and View ownership is clear.
- `Game.cs`, `BattleLoopRunner`, and turn commands orchestrate rather than implement battle rules.
- `BattleLoopRunner` contains no damage, formatting, parsing, or validation logic.
- Battle logic lives in `Models/Battle`.
- Dedicated Models classes perform calculations and resolutions.
- Runtime-data reading, JSON parsing, definition parsing, and catalog construction live in `Models/RuntimeData` and remain separate when they change for different reasons.
- Team-file parsing and team validation live in `Models/TeamSelection` but remain separate responsibilities.
- Team-selection prompts, option formatting, and user input live in `TeamSelectionView`.
- User-facing interaction, formatting, and user-input parsing live in `View`.
- Console- and GUI-specific behavior stays inside `Octopath-Traveler-View`.
- High-level and low-level classes depend on interfaces rather than concrete implementations.
- Abstractions are independent of implementation details.
- `Models` has no dependency on `Controller` or `View`.
- Battle models, skills, passive skills, effects, selectors, factories, executors, results, and outcomes remain presentation-neutral.
- Skill effects change domain state and do not generate user-facing text.
- Models do not store printable messages or display logs for View.
- Deterministic target selection remains in Models.
- User-driven target selection is coordinated by Controller and View without adding a Models-to-View dependency.
- Structured results cross the Models-to-View boundary.
- Specialized result objects carry damage, HP changes, status effects, revives, breaks, and turn outcomes.
- View formats, groups, and orders messages from structured results.
- View has no announcement method per effect type.
- New presentation types are added through polymorphic result renderers without changing the general View interface.
- `View` has no dependency on `Controller`.
- `View` does not mutate Models directly.
- `Game.cs`, `BattleLoopRunner`, and turn commands receive view abstractions rather than concrete views.
- Controller logic contains no `ReadLine()`, `WriteLine()`, console, GUI, directory, or `.txt` assumptions.
- Console and GUI implementations can satisfy the same role-specific interfaces.
- A replacement GUI requires no modifications to `Models` or battle orchestration.
- Views are split, or created through a view factory, when distinct view roles require different dependencies.
- `Program.cs` or `Script.cs` acts as the composition root for concrete views and adapters.
- Circular dependencies, misplaced classes, direct view mutations, printable messages in models, display logs in battle state, effect-specific View methods, oversized view interfaces, and console-coupled controllers are grading-risk items.