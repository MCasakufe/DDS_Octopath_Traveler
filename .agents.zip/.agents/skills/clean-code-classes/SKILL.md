---
name: clean-code-classes
description: 'Clean Code class-design guidance for small cohesive classes, single responsibility, OCP-compliant skill composition, event-driven passive skills, Liskov substitution, interface segregation, abstraction design, and choosing between objects and simple data structures in the Octopath Traveler-inspired project.'
---

# Clean Code Classes

Use this skill for class size, responsibility, cohesion, facade design, polymorphism, Open-Closed Principle, active-skill composition, passive-skill extension points, Liskov Substitution Principle, Interface Segregation Principle, abstraction keywords, and choosing the appropriate axis of change.

## Priority Rule

- This file integrates the authoritative Cap 6, Cap 10, and SOLID lecture guides and supersedes conflicting prior class-design guidance.
- Keep classes small by responsibility. Prefer a model that can be extended without editing stable execution code, but do not introduce unnecessary subclasses for fixed data or trivial variants.

## Small Classes and Single Responsibility

1. **Measure class size by responsibilities**
- Keep classes small.
- Measure size by responsibilities, not by lines or method count.
- Give each class one reason to change.

2. **Keep classes cohesive**
- Keep few fields.
- Prefer methods that use the same fields.
- Review a class when isolated method groups use separate subsets of fields.
- Extract each cohesive subset into a dedicated class when it represents a separate responsibility.

3. **Separate reasons to change**
- Separate calculations, reporting, persistence, and presentation when they change for different reasons.
- Keep parsing, validation, calculation, execution, persistence, reporting, and presentation separate when they have different reasons to change.
- Keep business rules separate from presentation logic. Use `clean-code-systems` for the complete Models-to-View boundary rules.

4. **Use thin facades only when callers need one entry point**
- Introduce a thin facade or delegating domain object only when several specialized services need a stable entry point.
- Move the actual work into focused classes.
- Do not use a facade to hide an oversized class that still owns unrelated responsibilities.

## Class-Extraction Procedure

1. Start with an oversized method.
2. Extract small methods.
3. Group parameters that represent shared state.
4. Move that state into fields only when it genuinely belongs to one responsibility.
5. Identify methods that use only a subset of fields.
6. Move each cohesive subset into a dedicated class.
7. Repeat until further extraction would not clarify responsibilities.

Use `clean-code-functions` for method-level extraction, parameter-count limits, and abstraction-level review. Continue into class extraction when helper methods reveal separate responsibilities.

## Open-Closed Active-Skill Architecture

1. **Keep stable execution code closed to modification**
- Treat skills, skill effects, passive-skill handlers, conditions, and target selectors as extension points.
- Extend behavior by adding classes or composing existing behaviors rather than editing central execution flow.
- Treat adding a new type as a warning sign when it requires edits outside its own class and the factory wiring that selects it.

2. **Compose active skills from independent behaviors**
- Model each active skill as the composition of target selection and effect application.
- Reuse the same effect with different selectors and the same selector with different effects.
- Split large abstractions into independently reusable parts.
- Prefer `Skill = Condition + TargetSelector + Effect` when eligibility, targeting, and execution vary separately.
- Prefer composing active skills from reusable effects, conditions, and target selectors rather than creating one full execution path per skill.
- Use a bounded set of reusable primitives instead of one class per trivial variant:

```csharp
new MultiEffect(damageEffect, statusEffect)
new AndCondition(hpCondition, spCondition)
```

3. **Keep active-skill interfaces small and stable**
- Keep selector and effect interfaces small and stable.
- Do not add parameters whenever a new skill needs different data.
- Supply skill-specific dependencies through constructors or stable action-scoped request or execution-context objects.
- Avoid turning `BattleState` into an unrestricted mutable parameter bag. Use `clean-code-objects` for the state-boundary review.

4. **Move variant behavior behind abstractions**
- Do not branch on a skill name, concrete type, or other special identifier outside a factory.
- Do not add one executor method per skill type.
- Keep `TravelerSkillExecutor` independent of specific skill names, concrete skill-effect classes, and concrete target-selector classes.
- Review `TravelerSkillExecutor`, factories, and battle executors for growing conditional chains.
- Move variant-specific eligibility rules into the skill abstraction:

```csharp
if (skill.UserMeetsUseCondition(unit)) usableSkills.Add(skill);
```

5. **Use factories as the single mapping point**
- Centralize unavoidable skill-name or type mapping inside factories.
- Use factories as the single mapping point from runtime definitions to concrete skills, effects, conditions, selectors, and passive-skill handlers.
- Use abstractions rather than concrete implementations in executors and factories.

6. **Avoid functional modeling when it replaces proper polymorphism**
- Do not centralize extensible ability behavior in functional-style dispatch or conditionals when the behavior belongs in polymorphic classes.

7. **Keep interchangeable implementations substitutable**
- Keep selectors interchangeable wherever a selector abstraction is expected.
- Avoid broad skill subclasses when a smaller reusable effect, condition, selector, or behavior is sufficient.

## Event-Driven Passive Skills

1. **Keep passive skills separate from active effects**
- Do not add passive-skill lifecycle methods such as `ApplyAtStartOfGame()` or `ApplyAtEndOfTurn()` to a general active-effect interface.
- Do not scatter passive-skill conditionals throughout battle execution.

2. **Trigger passive behavior through domain events**
- Use a publisher-subscriber mechanism keyed by event type.
- Publish events from the class that owns each lifecycle boundary, such as round completion, turn execution, damage resolution, or status-effect application.
- When a passive skill needs a genuinely new event type, publish that event once at the appropriate domain boundary instead of adding skill-specific checks.

3. **Manage handler lifetimes explicitly**
- Register and unregister passive handlers explicitly when their lifetime is limited.
- Review whether future passive-skill handlers can follow the same event-driven approach as `ExtraTurnPassiveSkillHandler`.
- New passive skills should be addable as handlers without changing battle-loop orchestration.

## Choose the Appropriate Axis of Change

1. **Use simple data structures and procedural services when operations vary**
- When the data shape is stable but new operations will be added frequently, prefer simple data structures and procedural services.

2. **Keep fixed combat stats simple**
- Do not introduce unnecessary subclasses merely to represent the fixed set of combat-stat values.

3. **Avoid class explosion and cross-class duplication**
- Use polymorphism to reduce central conditionals and duplication, not to multiply classes without clarity.
- Refactor a polymorphic model if it duplicates logic across classes or creates subclasses that do not represent meaningful behavioral variation.

## Liskov Substitution

1. **Preserve the base-type contract**
- Make every subclass safely substitutable for its base class.
- Do not introduce derived classes that break assumptions made by clients of the base abstraction.

2. **Declare common members at the proper abstraction level**
- If all child classes define the same member, place it in the base or abstract class.

3. **Use `virtual` intentionally**
- Do not make methods virtual by default.
- Mark a method as virtual only when overriding is intended and used.

4. **Use `abstract` intentionally**
- Mark an unimplemented parent method as abstract.
- Declare a class abstract when it exists only as an abstraction and should not be instantiated directly.

## Interface Segregation

1. **Keep interfaces small and role-specific**
- Split large interfaces into focused interfaces when clients need different subsets of operations.
- Make each client depend only on the methods it uses.

2. **Do not force unused methods on implementations**
- No class should implement interface methods that are irrelevant to its role.
- Prefer small specialized classes and interfaces over one class or interface with unrelated responsibilities.

## Project-Specific Responsibility Review

- Keep `Game.cs` focused on application orchestration.
- Keep `BattleLoopRunner` focused on round flow. Avoid adding damage, formatting, parsing, or validation logic.
- Keep turn commands focused on coordinating one action.
- Keep calculations in dedicated Models classes such as damage calculators and resolvers.
- Keep skill effects focused on changing battle state. Do not make damage, healing, revive, or status-effect classes generate user-facing text.
- Keep runtime-data reading, JSON parsing, definition parsing, and catalog construction separate when they change for different reasons.
- Keep team-file parsing separate from team validation.
- Review whether `BattleState`, combat units, executors, factories, and validators have accumulated unrelated responsibilities.
- Introduce a thin facade only when several specialized battle services need a stable entry point.
- Use `clean-code-systems` for structured outcome objects and View formatting rules.

## Cross-Skill Links

- Use `clean-code-functions` for method size, helper extraction, argument design, and abstraction-level review.
- Use `clean-code-objects` for object-versus-data-structure roles, access modifiers, mutable-state protection, `BattleState` review, and Law of Demeter review.
- Use `clean-code-systems` for MVC ownership, dependency direction, user-driven target selection, view abstractions, presentation-neutral outcomes, and polymorphic View rendering.
- Use `clean-code-boundaries` for adapters around external or unmodifiable dependencies.

## Review Checklist

- Each class has one reason to change.
- No oversized class contains unrelated methods.
- No low-cohesion class has isolated method groups using separate field subsets.
- Calculations, reporting, persistence, presentation, parsing, validation, and execution remain separate when they change for different reasons.
- Thin facades delegate actual work to specialized classes.
- Ability modeling is OCP-compliant.
- Active skills compose reusable conditions, target selectors, and effects.
- The same effect can be reused with different selectors and the same selector with different effects.
- Selector and effect interfaces remain small and stable.
- Skill-specific dependencies are supplied through constructors or stable action-scoped contexts.
- Stable execution code is extended through new classes or composition rather than repeated edits.
- No skill-name checks or concrete-type checks remain outside factories.
- `TravelerSkillExecutor` is independent of specific skill names, concrete effects, and concrete selectors.
- Variant-specific eligibility rules live behind the skill abstraction.
- New active skills require only factory wiring and new or reused selectors and effects.
- Factories are the single mapping point from runtime definitions to concrete implementations.
- Composite behaviors replace duplicated combinations.
- Passive skills remain separate from active effects.
- Active-effect interfaces contain no passive lifecycle hooks.
- New passive skills subscribe to domain events instead of modifying battle-flow logic.
- Passive-skill conditionals are not duplicated across controllers, executors, or resolvers.
- Event publishers sit at the appropriate lifecycle boundary.
- Limited-lifetime passive handlers are registered and unregistered explicitly.
- Selectors remain interchangeable wherever a selector abstraction is expected.
- No executor method is added merely because a new skill type exists.
- Stable data shapes with frequently changing operations use simple data structures and procedural services where appropriate.
- Fixed combat stats remain simple.
- Polymorphism does not create unclear class explosions or cross-class duplication.
- Every subclass preserves the contract of its base type.
- Shared members live in base abstractions.
- `virtual` and `abstract` keywords are used intentionally.
- Interfaces are small and role-specific.
- Clients depend only on the interface methods they use.
- No class implements unused interface methods.
- Multiple responsibilities, cascading unrelated edits, OCP or LSP violations, oversized interfaces, inappropriate functional dispatch, and avoidable class explosions are grading-risk items.