---
name: clean-code-errors
description: 'Clean Code Ch. 7 guidance for exception-based failure handling, specific domain exceptions, null avoidance, Special Case objects, narrow try-catch placement, and structured valid battle outcomes in the Octopath Traveler-inspired project.'
---

# Clean Code Error Handling

Use this skill for failures, exceptions, `null` avoidance, Special Case objects, `try-catch` placement, boundary validation, and distinguishing invalid states from valid domain outcomes.

## Priority Rule

- This file integrates the authoritative Cap 7 lecture guide and supersedes conflicting prior error-handling guidance.
- Keep failure handling separate from the normal execution path.
- Use exceptions for invalid states or failed operations. Use structured result objects for valid domain outcomes.

## Exception Rules

1. **Use exceptions instead of error codes**
- Prefer exceptions over error codes, sentinel values, or booleans used only to report failure.
- Keep the normal execution path readable instead of mixing it with failure branches.

2. **Throw specific domain exceptions**
- Throw custom exceptions with domain-specific names.
- Do not throw or catch general exceptions such as `ApplicationException`.
- Use the existing specific exceptions where appropriate, such as `TeamFileParseException`, `BattleStateCreationException`, `InvalidTeamSetupException`, and `InvalidInputRequestException`.

3. **Catch only where recovery or translation is meaningful**
- Minimize `try-catch` blocks.
- Catch failures at the level that can handle them meaningfully.
- Prefer one `catch` per `try` block. Multiple catches require a clear justification.
- Do not catch an exception only to ignore it.
- Let exceptions propagate when the current layer cannot recover safely or translate the failure into an appropriate boundary response.

## Null Avoidance and Special Cases

1. **Do not return or accept `null`**
- Do not return `null`.
- Do not accept `null` arguments.
- Avoid nullable units, targets, runtime definitions, and catalog entries.
- Validate required data before battle execution begins.

2. **Use Special Case objects only for valid missing behavior**
- Use the Special Case pattern when a missing value is valid and a safe no-op or default object preserves the normal flow.
- Consider a no-op implementation for expected empty behavior, such as a selector that intentionally selects no targets.
- Do not use a Special Case object to hide invalid runtime data, unknown definitions, or programming errors.
- Do not silently replace an unknown skill definition with empty behavior.

## Valid Domain Outcomes Are Not Exceptions

- Use explicit result objects for valid battle outcomes such as misses, blocked attacks, failed flee attempts, or defeated targets.
- Keep exceptions for invalid states or failures that prevent safe continuation.
- Keep result objects presentation-neutral so View can render the outcome without moving error handling into Models.

## Project-Specific Guidance

- Review whether runtime-data readers and parsers throw specific exceptions for malformed files, invalid JSON, unknown skills, and unsupported definitions.
- Review whether factories throw specific creation exceptions instead of returning `null` when a requested effect, selector, passive-skill handler, or damage profile cannot be built.
- Handle parsing and setup exceptions near the Controller boundary so View can display an appropriate message without mixing failure handling into Models.
- Keep battle executors focused on normal flow. Let exceptions propagate when execution cannot continue safely.
- Use structured result objects for expected battle outcomes rather than booleans, sentinel values, or avoidable exceptions.

## Cross-Skill Links

- Use `clean-code-functions` for function-level separation of normal flow from failure handling.
- Use `clean-code-systems` for Controller, Models, and View placement and for structured Models-to-View results.
- Use `clean-code-boundaries` for adapters around file, JSON, console, GUI, and third-party dependencies.

## Review Checklist

- No `null` returns.
- No `null` arguments.
- No booleans used only as error codes.
- No sentinel values used to report failure.
- No general exceptions thrown or caught.
- No ignored exceptions.
- No repeated `try-catch` blocks obscuring the main flow.
- Each `catch` exists at a level that can handle or translate the failure meaningfully.
- Multiple catches on one `try` have a clear justification.
- Missing-but-valid behavior uses a Special Case object where appropriate.
- Invalid runtime data produces a specific exception.
- Unknown definitions do not silently become no-op behavior.
- Factories do not return `null` when creation fails.
- Expected battle outcomes use structured results, not exceptions.
- Parsing and setup exceptions are handled near the Controller boundary when View must display an appropriate message.
- Error codes, nullable APIs, general exceptions, unnecessary catches, ignored failures, and avoidable exceptions are grading-risk items.