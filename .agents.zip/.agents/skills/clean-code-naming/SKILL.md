---
name: clean-code-naming
description: 'Clean Code Ch. 2 guidance for precise, searchable, consistent C# names in the Octopath Traveler-inspired project.'
---

# Clean Code Naming

Use this skill for file, type, member, variable, parameter, constant, enum, and value-object naming.

## Priority Rule

- This file integrates the authoritative Cap 2 lecture guide and supersedes conflicting prior naming guidance.
- Use project vocabulary and C# conventions consistently across Controller, Models, and View.

## Rules

1. **Reveal intent precisely**
- A name should clarify why something exists, what it does, and how it is used.
- Include units when relevant, such as `durationInRounds`, `damagePercentage`, or `maxHp`.

2. **Avoid misleading names**
- Do not imply a collection type, state, or responsibility that the value does not have.
- Avoid names that differ only by small details while representing unrelated behavior.

3. **Make distinctions meaningful**
- Different names must represent real differences.
- Avoid suffixes such as `data1`, `data2`, `info`, or `object` unless they describe a genuine distinction.

4. **Use searchable names**
- Replace unexplained strings and numbers with named constants, enums, or dedicated value objects.
- Apply the same treatment to literal booleans only when their meaning is otherwise opaque.

5. **Use the correct grammatical form**
- Use nouns or noun phrases for classes, fields, variables, and objects.
- Use verbs or verb phrases for methods.

6. **Use one word per concept**
- Pick one term for each concept and use it consistently.
- Do not alternate between terms such as `Get`, `Fetch`, and `Retrieve` for the same operation.
- Do not reuse the same word for different concepts.

7. **Use the correct vocabulary**
- Use standard software terms for technical concepts, such as `Factory`, `Parser`, `Selector`, `Queue`, or `Validator`.
- Use game-domain terms for domain concepts, such as `Traveler`, `Beast`, `Skill`, `Effect`, `Shield`, or `Break`.

8. **Use context without redundancy**
- Add context through classes, methods, and namespaces.
- Do not repeat context already provided by the surrounding scope.
- Prefer short names only when they remain unambiguous.
- Avoid one-character identifiers in production logic unless a tiny local scope makes the meaning obvious.

## C# Naming Conventions

| Element                              | Convention        |
| ------------------------------------ | ----------------- |
| Private field                        | `_lowerCamelCase` |
| Public, protected, or internal field | `UpperCamelCase`  |
| Property                             | `UpperCamelCase`  |
| Method                               | `UpperCamelCase`  |
| Class                                | `UpperCamelCase`  |
| Interface                            | `IUpperCamelCase` |
| Local variable                       | `lowerCamelCase`  |
| Parameter                            | `lowerCamelCase`  |

## Project-Specific Guidance

- Keep names consistent across Controller, Models, and View.
- Distinguish runtime definitions, selected setups, and battle-state objects clearly, such as `TravelerDefinition`, `TravelerSetup`, and `TravelerCombatUnit`.
- Review similarly named battle types such as requests, calculations, resolutions, results, outcomes, and execution states. Ensure each suffix describes a distinct role.
- Prefer domain-specific names in skill effects and selectors. A selector name should state what it selects and the selection rule, such as `LowestCurrentHpBeastTravelerSkillTargetSelector`.
- Keep factories, parsers, validators, calculators, resolvers, executors, handlers, and views named according to their actual responsibility.
- Replace skill-name strings, damage-type strings, status strings, and unexplained numeric thresholds with constants, enums, or dedicated value objects where appropriate.
- Review abbreviations such as `Hp`, `Sp`, `PhysAtk`, and `ElemDef`. Use one spelling consistently throughout the codebase.
- Avoid generic names such as `data`, `item`, `value`, `state`, `result`, or `type` when the surrounding context does not make their meaning obvious.

## Large-Method Naming Guidance

- Do not rename away a large-method problem. Split or reduce the method when size makes local names unclear.
- A local name such as `player1` may be understandable in a small context but too vague inside a very large method.
- Factory construction methods may contain longer conditional chains when required to build objects, but their names must still reveal their responsibility.

## Review Checklist

- Names reveal intent.
- Names include units where relevant.
- Methods use verbs.
- Classes, fields, variables, and objects use nouns or noun phrases.
- Similar names represent similar concepts.
- Different concepts have clearly different names.
- One term is used consistently per concept.
- Constants, enums, or value objects replace magic strings and numbers.
- C# naming conventions are applied consistently.
- Ambiguous, misleading, inconsistent, non-searchable, or poorly distinguished names are grading-risk items.