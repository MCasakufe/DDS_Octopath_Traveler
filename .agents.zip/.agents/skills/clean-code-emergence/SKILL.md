---
name: clean-code-emergence
description: 'It is from Clean Code, and the chapters that refers to this skill: Ch. 12 — 4 rules of simple design (Kent Beck).'
---

complete body