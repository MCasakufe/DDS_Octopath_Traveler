---
name: clean-code-boundaries
description: 'Clean Code boundary guidance for encapsulating external libraries, mutable collection implementations, file and JSON details, console and GUI APIs, and unfinished dependencies behind application-owned adapters or domain wrappers in the Octopath Traveler-inspired project.'
---

# Clean Code Boundaries

Use this skill for external or unmodifiable dependencies, mutable collection boundaries, adapters, runtime-data boundaries, file-system access, JSON parsing, console and GUI isolation, and focused dependency tests.

## Priority Rule

- This file integrates the authoritative Cap 8 and SOLID dependency-inversion lecture guides and supersedes conflicting prior boundary guidance.
- Keep implementation details behind application-owned adapters or domain-specific wrappers. Expose only the operations that the project needs.

## External Dependency Isolation

1. **Wrap external or unmodifiable dependencies with abstractions you control**
- Do not spread calls to third-party APIs, framework-specific services, file-system APIs, JSON libraries, directory APIs, console primitives, or GUI primitives through application logic.
- Put each external or unmodifiable dependency behind an application-owned adapter or boundary class.
- Make callers depend on interfaces or abstractions controlled by the application rather than on concrete external implementations.
- Keep boundary abstractions independent of the implementation details that they wrap.
- Define operations in domain or application terms rather than copying the low-level API.

2. **Prefer composition over inheritance at external boundaries**
- Avoid inheriting from external classes.
- Prefer composition so an external implementation can be replaced without distorting the domain model.

3. **Isolate representation-specific work**
- Keep casts, conversions, file access, JSON parsing, and third-party API calls inside boundary classes.
- Isolate directory paths, file names, `.txt` assumptions, storage formats, GUI-library types, and console primitives at the corresponding application edge.

4. **Use adapters for unfinished dependencies**
- Introduce an adapter when another module, library, or team has not delivered its final implementation.
- Keep the temporary integration behind the same application-owned abstraction expected by callers.

## Collection Boundaries

1. **Keep mutable collections private**
- Do not pass `List<T>`, `Dictionary<TKey, TValue>`, or other mutable boundary collection types widely through the codebase.
- Keep collections private inside domain-specific wrappers or owning classes.
- Do not leak a collection merely because several collaborators need related operations.

2. **Expose only required domain operations**
- Expose the narrow operations that the project needs.
- Hide generic operations such as `Clear()`, unrestricted mutation, and representation-specific access unless they are genuine domain operations.
- Let the owning Models class decide how to store, retrieve, filter, and validate its collection.
- When exposing an array is sufficient, prefer it over leaking a mutable collection API.

```csharp
public class Team
{
    private readonly List<Unit> _units = new();

    public void Add(Unit unit) => _units.Add(unit);
    public Unit Get(int index) => _units[index];
}
```

## Dependency Tests

- Add learning tests for external libraries and dependencies.
- Verify the behavior that the project relies on so breaking updates are detected.
- Add focused boundary tests for the GUI adapter, runtime-data loading, JSON parsing, and other external dependencies used by the project.

## Project-Specific Guidance

- Avoid passing `List<Unit>` through skill effects, target selectors, battle execution, or View methods. Prefer domain abstractions such as `Team`, target groups, or selection-result types.
- Review whether traveler and beast collections, turn queues, selected targets, status effects, and passive-skill handlers need dedicated wrappers.
- Keep collection-specific operations inside their owning Models classes.
- Use `RuntimeDataFileReader`, `RuntimeDataJsonParser`, definition parsers, and `RuntimeDataCatalog` as boundaries around file-system and JSON details.
- Keep team-file parsing and validation inside `Models/TeamSelection`, using focused classes such as `TeamFileParser` and `TeamSetupValidator`.
- Keep `OctopathTravelerGUI.dll` usage inside View adapters. Do not leak GUI-library types into Controller or Models.
- Keep console APIs inside View classes such as `ConsoleView`. Do not leak `ReadLine()`, `WriteLine()`, or console-specific types into Controller.
- Create concrete adapters only in the composition root, such as `Program.cs` or `Script.cs`.

## Cross-Skill Links

- Use `clean-code-systems` for view interfaces, MVC dependency direction, and composition-root wiring.
- Use `clean-code-errors` for specific exceptions raised by file, JSON, runtime-data, and other boundary failures.

## Review Checklist

- External or unmodifiable dependencies are isolated behind application-owned adapters.
- Callers depend on abstractions rather than concrete external implementations.
- Boundary abstractions are independent of implementation details.
- No `List<T>` or `Dictionary<TKey, TValue>` is passed widely through public APIs.
- Collections remain private inside domain-specific wrappers or owning classes.
- No unrestricted external-collection methods are exposed unnecessarily.
- Arrays are generally exempt from collection-boundary deductions.
- No application class inherits from an external library class unnecessarily.
- Casts, conversions, file access, JSON parsing, console APIs, GUI APIs, and third-party calls remain isolated.
- Runtime-data loading and parsing remain behind focused abstractions in `Models/RuntimeData`.
- Team-file parsing and validation remain inside `Models/TeamSelection`.
- `OctopathTravelerGUI.dll` types do not leak into Controller or Models.
- Console-specific operations do not leak into Controller.
- Temporary or unfinished dependencies remain behind adapters.
- Third-party behavior relied on by the project is covered by learning or boundary tests.
- Replacing a collection implementation requires changes in one owning class only.
- Replacing an external dependency requires changes only in its adapter.
- Collection or library usage outside an encapsulating boundary class is a grading-risk item.