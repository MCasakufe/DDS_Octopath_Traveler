---
name: clean-code-concurrency
description: 'It is from Clean Code, and the chapters that refers to this skill: Ch. 13 — Thread safety, keep concurrency separate.'
---

complete body