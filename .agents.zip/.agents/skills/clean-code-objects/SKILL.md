---
name: clean-code-objects
description: 'Clean Code Ch. 6 guidance for object and data-structure boundaries, encapsulation, access modifiers, DTO-like request and result types, BattleState scope, and the Law of Demeter in the Octopath Traveler-inspired project.'
---

# Clean Code Objects and Data Structures

Use this skill for encapsulation, visibility, object-versus-data-structure decisions, hybrid-class detection, request and result objects, `BattleState` scope, train wrecks, and Law of Demeter review.

## Priority Rule

- This file integrates the authoritative Cap 6, Cap 10, and SOLID lecture guides and supersedes conflicting prior object-design guidance.
- Apply the Law of Demeter to behavior-rich objects. Do not apply it mechanically to plain data structures.
- Keep `BattleState` focused on genuine battle state. Do not turn it into a generic mutable parameter bag or a presentation log.

## Encapsulation and Visibility

1. **Default to private members**
- Keep fields and methods private unless another class must use them.
- Expose the narrowest public surface required by collaborators.
- Review access modifiers in `Unit`, `TravelerCombatUnit`, and `BeastCombatUnit`.

2. **Expose domain operations instead of mutable internals**
- Do not expose internal state automatically through public getters and setters.
- Prefer operations such as applying damage, healing, spending resources, or changing shields over unrestricted mutation of combat state.
- If an external class needs a public member only to manipulate another object's internals, redesign the collaboration rather than merely widening access.

## Objects, Data Structures, and Hybrids

1. **Choose one role for each class**
- Object: hide data and expose behavior.
- Data structure: expose data and keep behavior minimal.

2. **Do not create hybrids**
- Do not combine exposed mutable internals with domain behavior in the same class.
- A class that exposes data for external manipulation while also implementing business behavior is a hybrid violation.

3. **Keep transport-only types simple**
- Keep runtime definitions, parsing records, action-scoped requests, execution contexts, results, and similar transport types as simple data structures when they only carry data.
- Use focused request or context objects when several effects need shared execution data.
- Use structured result types for damage, HP changes, status effects, revives, breaks, and turn outcomes.

4. **Protect the scope of `BattleState`**
- Do not turn `BattleState` into an unrestricted mutable parameter bag for every executor, selector, effect, parser, or renderer.
- Do not store printable messages or display logs such as `List<string>` inside battle state merely so View can print them.
- Prefer action-scoped request or context objects for execution inputs.
- Prefer specialized result types over a generic state object that carries unrelated mutable fields and presentation logs.

5. **Keep behavior-oriented services encapsulated**
- Services such as `TeamSetupValidator` should expose the validation operation and hide internal checks.

## Law of Demeter

1. **Limit object navigation**
- For a method in a class, call methods only on:
  - Its own class.
  - Objects it creates.
  - Its parameters.
  - Objects stored directly in its fields.
- Do not navigate through returned objects to reach deeper internals of a behavior-rich object.

2. **Remove train wrecks**
- Replace chained navigation such as:

```csharp
context.GetOptions().GetDirectory().GetPath();
```

- Introducing local variables is a minimum readability fix, not the final design. Move the required operation into the object that owns the necessary knowledge:

```csharp
context.GetDirectoryPath();
```

3. **Treat plain data structures differently**
- Do not apply the Law of Demeter mechanically to plain data structures.
- A simple access chain over data-only structures is not automatically a Demeter violation. Review whether the chain exposes behavior-rich internals before refactoring it.

## MVC Boundary Guidance

- Check Controller, Models, and View boundaries for chained navigation into internal objects.
- Add an operation to the class that owns the required knowledge instead of exposing nested internals.
- Keep the Controller focused on orchestration. Keep battle rules and state transitions inside Models rather than extracting model data for external manipulation.
- Keep structured request, context, result, and outcome objects presentation-neutral.
- Use `clean-code-systems` for the complete MVC dependency, structured-result rendering, and placement rules.

## Cross-Skill Links

- Use `clean-code-classes` for single responsibility, cohesion, polymorphism-versus-procedural-design choices, active-skill composition, and passive-skill extension points.
- Use `clean-code-systems` for MVC ownership, dependency direction, structured Models-to-View outcomes, and view-abstraction rules.

## Review Checklist

- No unnecessary public fields, methods, getters, or setters.
- Mutable combat state is changed through domain operations.
- Each class is clearly an object or a data structure, not a hybrid.
- Runtime definitions, parsing records, action-scoped requests, execution contexts, results, and similar transport types remain simple when they only carry data.
- `BattleState` contains genuine battle state rather than unrelated execution inputs or presentation details.
- `BattleState` is not an unrestricted mutable parameter bag.
- Printable messages and display logs such as `List<string>` are not stored in battle state.
- Focused request or context objects carry shared action inputs.
- Specialized structured result types carry damage, HP changes, status effects, revives, breaks, and turn outcomes.
- Validators expose one clear public operation and hide internal checks.
- No train wreck method chains navigate through behavior-rich internals.
- Local-variable rewrites are treated as intermediate cleanup when an owning-object operation is appropriate.
- The Law of Demeter is applied to objects without being imposed mechanically on plain data structures.
- Controller and View do not manipulate Models internals directly.
- Access-modifier errors, hybrid classes, `BattleState` misuse, Demeter violations, and train wrecks are grading-risk items.